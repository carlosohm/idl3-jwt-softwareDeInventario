<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Establishment extends Model
{
    
    protected $table = 'establishments';
    protected $primaryKey = 'id_establishment';

   
  
}
